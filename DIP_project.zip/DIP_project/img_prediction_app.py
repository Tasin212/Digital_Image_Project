#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 18:20:19 2023

@author: mohammedabbasuddintasin
"""
'''
import numpy as np
import pickle
import streamlit as st
import numpy as np
from skimage.io import imread
from skimage.transform import resize
import pickle
from PIL import Image



#loading the saved model
model = pickle.load(open('/Users/mohammedabbasuddintasin/Programming/Project/img_project/img_model.p', 'rb'))



def main():
    st.set_option('deprecation.showfileUploaderEncoding', False)
    st.title('Image Classifier')
    st.text('Upload the image')
    uploaded_file = st.file_uploader('Choose an image...', type='png')
    if uploaded_file is not None:
      img = Image.open(uploaded_file)
      st.image(img,caption='Uploaded Image')

      if st.button('PREDICT'):
        CATEGORIES = ['benign', 'malignant', 'normal']
        st.write('Result....')
        flat_data=[]
        img = np.array(img)
        img_resized = resize(img, (150, 150, 3))
        flat_data.append(img_resized.flatten())
        flat_data = np.array(flat_data)
        y_out = model.predict(flat_data)
        y_out = CATEGORIES[y_out[0]]
        st.title(f' PREDICTED OUTPUT : {y_out}')
        
        


if __name__ == '__main__':
    main()

# /Users/mohammedabbasuddintasin/Programming/Project/img_project/our.pkl
# app.py
import streamlit as st
import cv2
import numpy as np
from skimage import exposure, feature, restoration
import joblib

# Load the pre-trained classifier
classifier = joblib.load('/Users/mohammedabbasuddintasin/Programming/Project/img_project/our.pkl')

def preprocess_image(img):
    # Convert the image to grayscale
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Normalize pixel values to [0, 1]
    img_gray = img_gray / 255.0

    # Histogram equalization
    img_equalized = exposure.equalize_hist(img_gray)

    # Denoising
    img_denoised = restoration.denoise_tv_chambolle(img_equalized, weight=0.1)

    return img_denoised

def predict(image):
    # Ensure that the input features have the same number of dimensions as expected by the model
    if image.shape[0] != 4105:  # Update this with the correct number of features expected by the model
        st.error(f"Expected 4105 features, but got {image.shape[0]} features.")
        return None
    # Flatten image
    img_flatten = image.flatten()

    # Extract LBP features
    lbp_features = feature.local_binary_pattern(image, P=8, R=1, method="uniform")
    lbp_hist, _ = np.histogram(lbp_features.ravel(), bins=np.arange(0, 10), range=(0, 9))

    # Concatenate LBP features with flattened image
    img_combined = np.hstack((img_flatten, lbp_hist))

    # Make a prediction
    prediction = classifier.predict([img_combined])

    return prediction[0]

# Streamlit app code
st.title("Breast Cancer Detection App")

uploaded_file = st.file_uploader("Choose an image...", type="png")

if uploaded_file is not None:
    # Read the uploaded image
    img = cv2.imdecode(np.frombuffer(uploaded_file.read(), np.uint8), cv2.IMREAD_COLOR)

    # Preprocess the image
    preprocessed_img = preprocess_image(img)

    # Make a prediction
    prediction = predict(preprocessed_img)

    # Display the original and preprocessed images
    st.image(img, caption="Original Image", use_column_width=True)
    st.image(preprocessed_img, caption="Preprocessed Image", use_column_width=True)

    # Display the prediction result
    st.write(f"Prediction: {prediction}")


'''





import os
import streamlit as st
import cv2
import numpy as np
from skimage import exposure, feature, restoration
import joblib  # For joblib-based model loading

# Load the pre-trained classifier
classifier = joblib.load('/Users/mohammedabbasuddintasin/Programming/Project/img_project/our.pkl')

def preprocess_user_input(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (64, 64))

    # Convert to grayscale
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Normalize pixel values to [0, 1]
    img_gray = img_gray / 255.0

    # Histogram equalization
    img_equalized = exposure.equalize_hist(img_gray)

    # Denoising
    img_denoised = restoration.denoise_tv_chambolle(img_equalized, weight=0.1)

    # Flatten image
    img_flatten = img_denoised.flatten()

    # Extract LBP features
    lbp_features = feature.local_binary_pattern(img_denoised, P=8, R=1, method="uniform")
    lbp_hist, _ = np.histogram(lbp_features.ravel(), bins=np.arange(0, 10), range=(0, 9))

    # Concatenate LBP features with flattened image
    img_combined = np.hstack((img_flatten, lbp_hist))

    return img_combined

# Streamlit app code
st.title("Breast Cancer Detection App")

uploaded_file = st.file_uploader("Choose an image...", type="png")

if uploaded_file is not None:
    # Save the uploaded image temporarily
    temp_image_path = 'temp_image.jpg'
    with open(temp_image_path, 'wb') as f:
        f.write(uploaded_file.read())

    # Preprocess the user input image
    user_input_features = preprocess_user_input(temp_image_path)

    # Ensure that the input features have the same number of dimensions as expected by the model
    expected_features = 4105  # Update this with the correct number of features expected by the model

    if user_input_features.shape[0] != expected_features:
        st.error(f"Expected {expected_features} features, but got {user_input_features.shape[0]} features.")
    else:
        # Make a prediction
        prediction = classifier.predict([user_input_features])

        # Display the original and preprocessed images
        st.image(temp_image_path, caption="Input Image", use_column_width=True)

        # Display the prediction result
        st.write(f"Prediction: {prediction[0]}")

    # Remove the temporary image file
    os.remove(temp_image_path)








